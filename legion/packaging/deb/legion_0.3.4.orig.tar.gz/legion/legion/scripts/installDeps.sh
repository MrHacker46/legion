#!/bin/bash
pip install scapy
gem install snmp
