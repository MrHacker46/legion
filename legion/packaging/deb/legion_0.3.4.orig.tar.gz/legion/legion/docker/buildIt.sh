#!/bin/bash
docker build -t legion .
